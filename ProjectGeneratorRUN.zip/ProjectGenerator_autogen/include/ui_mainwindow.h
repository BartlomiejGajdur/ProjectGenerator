/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLineEdit *FilePath;
    QToolButton *toolButton;
    QToolButton *helpButton;
    QLineEdit *ProjectNameLineEdit;
    QCheckBox *MainFIle;
    QCheckBox *CMakeFile;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *ConanFile;
    QComboBox *ConanLibraryComboBox;
    QHBoxLayout *horizontalLayout_3;
    QCheckBox *RunnerFile;
    QLineEdit *GeneratorLineEdit;
    QCheckBox *ClangFormatFile;
    QCheckBox *GitignoreFile;
    QPushButton *pushButton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(351, 435);
        MainWindow->setMinimumSize(QSize(351, 435));
        MainWindow->setMaximumSize(QSize(351, 435));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        FilePath = new QLineEdit(centralwidget);
        FilePath->setObjectName("FilePath");
        FilePath->setMouseTracking(false);
        FilePath->setReadOnly(true);

        horizontalLayout->addWidget(FilePath);

        toolButton = new QToolButton(centralwidget);
        toolButton->setObjectName("toolButton");

        horizontalLayout->addWidget(toolButton);

        helpButton = new QToolButton(centralwidget);
        helpButton->setObjectName("helpButton");

        horizontalLayout->addWidget(helpButton);


        verticalLayout->addLayout(horizontalLayout);

        ProjectNameLineEdit = new QLineEdit(centralwidget);
        ProjectNameLineEdit->setObjectName("ProjectNameLineEdit");
        ProjectNameLineEdit->setClearButtonEnabled(true);

        verticalLayout->addWidget(ProjectNameLineEdit);

        MainFIle = new QCheckBox(centralwidget);
        MainFIle->setObjectName("MainFIle");

        verticalLayout->addWidget(MainFIle);

        CMakeFile = new QCheckBox(centralwidget);
        CMakeFile->setObjectName("CMakeFile");

        verticalLayout->addWidget(CMakeFile);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        ConanFile = new QCheckBox(centralwidget);
        ConanFile->setObjectName("ConanFile");

        horizontalLayout_2->addWidget(ConanFile);

        ConanLibraryComboBox = new QComboBox(centralwidget);
        ConanLibraryComboBox->addItem(QString());
        ConanLibraryComboBox->addItem(QString());
        ConanLibraryComboBox->addItem(QString());
        ConanLibraryComboBox->addItem(QString());
        ConanLibraryComboBox->setObjectName("ConanLibraryComboBox");

        horizontalLayout_2->addWidget(ConanLibraryComboBox);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        RunnerFile = new QCheckBox(centralwidget);
        RunnerFile->setObjectName("RunnerFile");

        horizontalLayout_3->addWidget(RunnerFile);

        GeneratorLineEdit = new QLineEdit(centralwidget);
        GeneratorLineEdit->setObjectName("GeneratorLineEdit");

        horizontalLayout_3->addWidget(GeneratorLineEdit);


        verticalLayout->addLayout(horizontalLayout_3);

        ClangFormatFile = new QCheckBox(centralwidget);
        ClangFormatFile->setObjectName("ClangFormatFile");

        verticalLayout->addWidget(ClangFormatFile);

        GitignoreFile = new QCheckBox(centralwidget);
        GitignoreFile->setObjectName("GitignoreFile");

        verticalLayout->addWidget(GitignoreFile);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");

        verticalLayout->addWidget(pushButton);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "ProjectGenerator", nullptr));
        FilePath->setPlaceholderText(QCoreApplication::translate("MainWindow", "Folder path", nullptr));
        toolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        helpButton->setText(QCoreApplication::translate("MainWindow", "?", nullptr));
        ProjectNameLineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Project name", nullptr));
        MainFIle->setText(QCoreApplication::translate("MainWindow", "Main", nullptr));
        CMakeFile->setText(QCoreApplication::translate("MainWindow", "CMake", nullptr));
        ConanFile->setText(QCoreApplication::translate("MainWindow", "Conan", nullptr));
        ConanLibraryComboBox->setItemText(0, QCoreApplication::translate("MainWindow", "fmt", nullptr));
        ConanLibraryComboBox->setItemText(1, QCoreApplication::translate("MainWindow", "nlohmann_json", nullptr));
        ConanLibraryComboBox->setItemText(2, QCoreApplication::translate("MainWindow", "zlib", nullptr));
        ConanLibraryComboBox->setItemText(3, QCoreApplication::translate("MainWindow", "sfml", nullptr));

        RunnerFile->setText(QCoreApplication::translate("MainWindow", "Runner", nullptr));
        GeneratorLineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Gen. e.g Unix Makefiles", nullptr));
        ClangFormatFile->setText(QCoreApplication::translate("MainWindow", "ClangFormat", nullptr));
        GitignoreFile->setText(QCoreApplication::translate("MainWindow", "Gitignore", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Generate", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
